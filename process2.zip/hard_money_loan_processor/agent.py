# --- FILE: hard_money_loan_processor/agent.py ---

import os
# asyncio and simulation functions removed, as the ADK CLI/Server handles the runtime

from google.adk.agents import SequentialAgent
# No need to import sub-components like ValuationLoopDecider or receive_underwriter_decision here,
# as they are referenced within their respective sub_agent definitions and don't need to be
# explicitly exposed or used by the root agent's definition itself.
# The tools used directly by the root agent (if any) or by its immediate sub_agents
# might need to be imported if they are not defined within the sub_agent files themselves
# or if the root agent's instruction directly refers to them for tool calling.
# In this design, tools are primarily assigned directly to the sub_agents that use them,
# or to the SequentialAgent if used by multiple sub-agents *within* that sequence.
# Let's re-import only what's necessary for the root definition if needed.

# Import all the defined *sub-agents* that will be part of the root SequentialAgent
from hard_money_loan_processor.sub_agents.intake_agent import intake_agent
from hard_money_loan_processor.sub_agents.property_valuation_agent import property_valuation_agent
from hard_money_loan_processor.sub_agents.borrower_qualification_agent import borrower_qualification_agent
from hard_money_loan_processor.sub_agents.underwriting_review_agent import underwriting_review_agent
from hard_money_loan_processor.sub_agents.document_generation_agent import document_generation_agent
from hard_money_loan_processor.sub_agents.closing_coordinator_agent import closing_coordinator_agent

# Also re-import the base tools if they are needed by the root agent's instruction directly (less common)
# from hard_money_loan_processor.tools.loan_origination_tools import LOS_UPDATE_STATUS_TOOL

# --- Main Root Agent: The Hard Money Loan Processor MAS ---

# The root agent will be a SequentialAgent coordinating the main stages of the process.
root_agent = SequentialAgent(
    name="HardMoneyLoanProcessorMAS",
    # No LLM 'model' is needed for a SequentialAgent as it only orchestrates sub-agents.
    description="A multi-agent system for processing hard money loans in California.",
    # The SequentialAgent's instruction isn't heavily used for delegation (AutoFlow happens
    # based on sub-agent order), but its description is important for how the system is presented.
    instruction="Orchestrates the end-to-end Hard Money Loan Processing workflow.",
    # Tools can be added here if the SequentialAgent itself needed to call them directly,
    # but typically tools are assigned to the LlmAgents that use them within the workflow.
    tools=[], # Keeping this empty as tools are assigned to sub-agents

    sub_agents=[
        # The sub-agents define the actual steps and contain the LLM logic and tools.
        intake_agent,                 # Step 1: Initial application intake
        property_valuation_agent,     # Step 2: Property valuation and LTV calculation
        borrower_qualification_agent, # Step 3: Borrower basic qualification
        underwriting_review_agent,    # Step 4: Human underwriter review (Human-in-the-Loop)
        document_generation_agent,    # Step 5: Document generation and e-signature sending
        closing_coordinator_agent     # Step 6: Monitor e-signatures and initiate funding
    ]
)

print("HardMoneyLoanProcessorMAS (SequentialAgent) defined with sub-agents.")

# --- ADK Entry Point ---
# For running with `adk web` or `adk api_server`, simply define the root_agent
# variable at the top level of the module. The ADK CLI/Server will discover it.
# No need for __main__ block or manual Runner setup for these tools.

# The file should end here, defining the root_agent variable.
# All simulation execution logic has been removed per instructions.
# --- FILE: hard_money_loan_processor/__init__.py ---

# This file makes the 'hard_money_loan_processor' directory a Python package
# and exposes the root_agent defined in agent.py for ADK CLI tools.

from .agent import root_agent

# You might also explicitly import key tools or sub-agents if you want them
# to be directly accessible when importing the package, though it's less common
# for internal components of a complex MAS.
# from .tools.loan_origination_tools import LOS_CREATE_TOOL
# from .sub_agents.intake_agent import intake_agent
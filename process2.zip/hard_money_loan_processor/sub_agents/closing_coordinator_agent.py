# --- FILE: hard_money_loan_processor/sub_agents/closing_coordinator_agent.py ---

from google.adk.agents import Agent, SequentialAgent, LoopAgent
from google.adk.events import Event, EventActions
from google.adk.agents.invocation_context import InvocationContext
from typing import List
from hard_money_loan_processor.tools.document_closing_tools import ESIGN_CHECK_TOOL, FUND_LOAN_TOOL
from hard_money_loan_processor.tools.loan_origination_tools import LOS_UPDATE_STATUS_TOOL
import time # Used in simulation examples, remove if not needed

# LlmAgent to call the check tool within the loop
# The check_signature_status tool itself updates the state['current_esign_status'].
# This agent's instruction guides the LLM to call the tool and interpret the state.
esign_check_llm_agent = Agent(
    name="EsignCheckLlmAgent",
    model="gemini-1.0-pro", # Cheaper model for a simple check
    description="Checks the e-signature status via tool and state.",
    instruction="Use the 'check_signature_status' tool with the transaction ID in state['current_esign_transaction_id']."
                "Report the current e-signature status (e.g., Pending, Completed, Declined) to the MLO.",
    tools=[ESIGN_CHECK_TOOL],
    # output_key="esign_check_result" # Save check result to state if needed
)

# Custom Agent to decide whether to continue polling for signature
# This agent contains the logic to read state and determine the loop flow.
class EsignLoopDecider(Agent):
     def __init__(self, **kwargs):
         # No LLM model needed for this purely logic-based agent.
         super().__init__(name="EsignLoopDecider", **kwargs)

     async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[Event, None]:
        print(f"--- Custom Agent: {self.name} deciding e-sign loop status ---")
        # The esign_check_llm_agent (the previous agent in the LoopAgent)
        # should have updated the 'current_esign_status' in state.
        esign_status = ctx.session.state.get('current_esign_status')
        print(f"--- Custom Agent: Current e-sign status in state: {esign_status} ---")

        is_done = (esign_status == 'Completed') # Match your API's 'Completed' status string
        is_failed = (esign_status in ['Declined', 'Expired', 'Error']) # Match your API's failure statuses

        if is_done:
            print(f"--- Custom Agent: E-signature completed. Escalating to exit loop. ---")
            # Yield an event that causes the LoopAgent to escalate/stop
            yield Event(author=self.name, actions=EventActions(escalate=True))
        elif is_failed:
            print(f"--- Custom Agent: E-signature failed ({esign_status}). Escalating to exit loop. ---")
            # Yield an event that causes the LoopAgent to escalate/stop
            yield Event(author=self.name, actions=EventActions(escalate=True))
        else:
            # If still pending, yield nothing or a message to let the LoopAgent continue
            print(f"--- Custom Agent: E-signature still pending. Continuing loop. ---")
            # Optionally, yield a message to the user, but this might make the UI noisy if polling frequently.
            # yield Event(author=self.name, content={"message": f"E-signature status is still '{esign_status}'. Waiting..."})
            # No specific action needed to continue; the absence of 'escalate' allows the loop to proceed.
            pass # Let the next iteration of the loop begin


# LoopAgent to poll for e-signature completion
esign_status_loop = LoopAgent(
    name="EsignStatusLoop",
    max_iterations=60, # Set a reasonable limit (e.g., 60 iterations * polling interval)
    # Consider adding a time delay between iterations in a real system to avoid excessive polling.
    # This might require a custom LoopAgent or careful management of the check tool itself.
    sub_agents=[
        # Sequence of agents within the loop:
        # 1. Call the check tool and update state (via LlmAgent)
        esign_check_llm_agent,
        # 2. Read state and decide if the loop should stop (via Custom Agent)
        EsignLoopDecider(name="EsignLoopDecisionMaker") # Give custom agent a name
    ]
)


# Define the Closing Coordinator Agent workflow
closing_coordinator_agent = SequentialAgent(
    name="ClosingCoordinatorAgent",
    model="gemini-2.0-flash", # Use an appropriate LLM to guide and finalize
    description="Coordinates the final closing steps, including monitoring e-signatures and initiating funding.",
    instruction="You are the Closing Coordinator Agent. Your task is to ensure documents are signed and initiate funding.",
    tools=[LOS_UPDATE_STATUS_TOOL, FUND_LOAN_TOOL], # Need LOS & Funding tools here for the final steps
    sub_agents=[
        # Step 1: Wait for e-signatures via the loop
        # The EsignStatusLoop will escalate when signing is Completed or Failed.
        esign_status_loop,
        # Step 2: Trigger funding if signatures were completed
        # This agent will run if EsignStatusLoop completes without being interrupted by a higher-level escalation.
        Agent( # Agent to trigger funding after signatures
              name="FundingTrigger",
              model="gemini-2.0-flash", # More capable model for decision/action
              instruction="E-signatures are complete (check state['current_esign_status'] is 'Completed')."
                          "Use the 'update_loan_status' tool to set status to 'Documents Signed' for app ID from state['current_application_id']."
                          "Then, use the 'fund_loan' tool with app ID from state['current_application_id'] to initiate funding."
                          "Report the result of funding initiation.",
              tools=[LOS_UPDATE_STATUS_TOOL, FUND_LOAN_TOOL] # Needs LOS update and Fund tool
        ),
        Agent( # Agent to finalize the loan status after funding is initiated
              name="FinalStatusUpdater",
              model="gemini-1.0-pro", # Cheaper model for simple status update and closing message
              instruction="Funding process initiated (check state['current_funding_status'] is 'Initiated')."
                          "Use the 'update_loan_status' tool to set status to 'Loan Funded' for app ID from state['current_application_id']."
                          "Congratulate the MLO, the hard money loan process is complete!",
              tools=[LOS_UPDATE_STATUS_TOOL] # Needs LOS update tool
        )
    ]
)

print("ClosingCoordinatorAgent (Sequential workflow including LoopAgent and Custom Agent) defined.")
# --- FILE: hard_money_loan_processor/sub_agents/intake_agent.py ---

from google.adk.agents import Agent
from hard_money_loan_processor.tools.loan_origination_tools import LOS_CREATE_TOOL, LOS_UPDATE_STATUS_TOOL
from typing import List

# Define the Intake Agent
intake_agent = Agent(
    name="IntakeAgent",
    model="gemini-2.0-flash", # Use an appropriate LLM
    description="Handles the initial intake of a hard money loan application from the MLO. Collects key details and creates the application in the LOS.",
    instruction="You are the Intake Agent for a Hard Money Loan Processor in California. "
                "Your role is to greet the MLO and collect the essential details for a new hard money loan application: "
                "1. Borrower's Full Name (Individual or Entity) "
                "2. Property Address (must be in California) "
                "3. Loan Amount Requested "
                "Once you have these three pieces of information, use the 'create_loan_application' tool to create the application in the LOS. "
                "Confirm the application creation to the MLO, including the application ID returned by the tool. "
                "Then, use the 'update_loan_status' tool to set the status to 'Intake Complete'. "
                "Do not proceed to the next steps of the loan process yourself. Your task is strictly intake."
                "If any required information is missing, politely ask the MLO for it.",
    tools=[LOS_CREATE_TOOL, LOS_UPDATE_STATUS_TOOL], # Assign relevant LOS tools
    # output_key="intake_summary" # Optional: Save agent's final response
)

print("IntakeAgent defined.")
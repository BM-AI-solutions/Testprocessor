# --- FILE: hard_money_loan_processor/sub_agents/borrower_qualification_agent.py ---

from google.adk.agents import Agent, SequentialAgent
from typing import List
from hard_money_loan_processor.tools.borrower_qualification_tools import BORROWER_BASIC_CHECK_TOOL, LIMITED_CREDIT_CHECK_TOOL
from hard_money_loan_processor.tools.loan_origination_tools import LOS_UPDATE_STATUS_TOOL

# Define the Borrower Qualification Agent
borrower_qualification_agent = SequentialAgent(
    name="BorrowerQualificationAgent",
    # Use an appropriate LLM for potential follow-up questions or synthesizing results
    model="gemini-2.0-flash",
    description="Evaluates the borrower's basic information and runs necessary checks for hard money loan eligibility.",
    # The SequentialAgent's instruction provides overall context but the sub-agents handle specific steps.
    instruction="Execute the necessary borrower qualification steps sequentially.",
    tools=[BORROWER_BASIC_CHECK_TOOL, LIMITED_CREDIT_CHECK_TOOL, LOS_UPDATE_STATUS_TOOL], # Assign tools needed by sub-agents or for direct use
    sub_agents=[ # Use sequential execution for checks
        Agent( # Agent to trigger basic check
            name="BasicInfoCheckTrigger",
            model="gemini-1.0-pro", # Cheaper model for a simple trigger task
            instruction="Use the 'check_borrower_basic_info' tool with borrower name from state['current_borrower_name'] and borrower type (try getting from state['current_borrower_type'], or ask the MLO if needed).",
            tools=[BORROWER_BASIC_CHECK_TOOL]
        ),
         Agent( # Agent to trigger credit check
            name="LimitedCreditCheckTrigger",
            model="gemini-1.0-pro", # Cheaper model for a simple trigger task
             instruction="Use the 'run_limited_credit_check' tool with the borrower name from state['current_borrower_name'].",
            tools=[LIMITED_CREDIT_CHECK_TOOL]
        ),
        Agent( # Agent to synthesize results and update status
            name="QualificationSynthesizer",
            model="gemini-2.0-flash", # More capable model to summarize and decide
             instruction="Synthesize the results from state['borrower_basic_check_status'] and state['borrower_credit_check_status']."
                         "Determine overall qualification status for hard money based on these checks."
                         "If both checks passed ('Passed' and 'Completed'), update the loan status to 'Borrower Qualified' using the 'update_loan_status' tool with the application ID from state['current_application_id']."
                         "If either check failed or had an error, update the loan status to 'Borrower Qualification Failed' using the 'update_loan_status' tool, specifying the application ID, and briefly explain the reason based on the status values in state."
                         "Report the outcome (Qualified or Failed) to the MLO.",
             tools=[LOS_UPDATE_STATUS_TOOL] # Need LOS tool here to update status
        )
    ]
)

print("BorrowerQualificationAgent (SequentialAgent) defined.")
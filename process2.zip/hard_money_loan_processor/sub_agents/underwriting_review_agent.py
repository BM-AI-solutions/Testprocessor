# --- FILE: hard_money_loan_processor/sub_agents/underwriting_review_agent.py ---

from google.adk.agents import Agent, SequentialAgent
from google.adk.events import Event, EventActions
from google.adk.tools import ToolContext, FunctionTool
from typing import Dict, Any, Optional
from hard_money_loan_processor.tools.loan_origination_tools import LOS_UPDATE_STATUS_TOOL
import time # Used in simulation examples, remove if not needed

# Define a Tool for Human-in-the-Loop (HILT) for underwriter review
# This tool simulates creating a task in an external system (task queue, UI backend, etc.).
def request_underwriter_review(
    application_id: str,
    loan_details_summary: str,
    tool_context: ToolContext
) -> Dict[str, Any]:
    """Creates a task in the underwriting system for a human underwriter to review the loan application.

    This tool simulates the interaction with an external task management system.

    Args:
        application_id: The ID of the loan application requiring review.
        loan_details_summary: A summary of key loan details (property, borrower, valuation, LTV, etc.) for the underwriter.
        tool_context: Provides access to session state.

    Returns:
        A dictionary indicating the result.
        If successful, includes 'status': 'pending', 'review_task_id': str, and message.
        If an error, includes 'status': 'error', 'error_message': str.
    """
    print(f"--- Tool: request_underwriter_review called for app ID: {application_id} ---")
    print(f"--- Loan Details Summary for Underwriter: {loan_details_summary} ---")

    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to your task management/underwriting system.
    # This API call would create a task for a human underwriter.

    underwriting_api_url = os.environ.get("UNDERWRITING_API_URL") # e.g., task queue, workflow engine
    api_key = os.environ.get("UNDERWRITING_API_KEY")

    if not underwriting_api_url or not api_key:
         return {"status": "error", "error_message": "Underwriting API URL or Key environment variable not set."}

    headers = {
        "Content-Type": "application/json",
        "X-API-Key": api_key
    }

    payload = {
        "applicationId": application_id,
        "summary": loan_details_summary,
        # Add other details needed by the underwriting system API
    }

    try:
        # Example: Making a POST request to create a review task
        api_response = requests.post(f'{underwriting_api_url}/review-tasks', json=payload, headers=headers)
        api_response.raise_for_status() # Raise HTTPError

        response_data = api_response.json() # Assuming the API returns JSON

        simulated_task_id = response_data.get("taskId") # Adjust key based on your API

        if not simulated_task_id:
             print("--- Tool Error: Underwriting API response missing task ID ---")
             return {"status": "error", "error_message": "Underwriting API response missing task ID or unexpected format."}

        # Store the task ID and status in state
        tool_context.state['current_underwriting_task_id'] = simulated_task_id
        tool_context.state['current_underwriting_status'] = 'Review Requested' # Initial status
        tool_context.state['awaiting_underwriter_input'] = True # Flag for HILT

        print(f"--- Tool: Underwriter review task created with ID {simulated_task_id}. ---")

        # Note: In a real HILT, the agent might pause here or enter a waiting state until the human action is received
        # via a different mechanism (e.g., a webhook updating session state, or a specific "receive_human_input" tool).
        # The ADK framework's Runner needs to be able to handle pausing and resuming, or you implement polling via a LoopAgent.
        # This tool simply reports that the task is requested. The waiting logic is in the agent workflow.

        return {"status": "pending", "review_task_id": simulated_task_id, "message": f"Underwriter review requested. Task ID: {simulated_task_id}. Waiting for human action."}

    except requests.exceptions.RequestException as e:
        print(f"--- Tool Error: Underwriting review request API failed: {e} ---")
        return {"status": "error", "error_message": f"Failed to request underwriter review via API: {e}"}
    except Exception as e:
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        return {"status": "error", "error_message": f"An unexpected error occurred during review request API call: {e}"}

    # --- END REAL API INTEGRATION ---

# A tool to receive human input for the review decision.
# In a real application, this would typically be triggered by an external system (e.g., webhook from a task UI
# or a manual input API endpoint exposed by your application).
# For demonstration, this tool might be called manually by the MLO user or an automated process simulating human input.
def receive_underwriter_decision(
    application_id: str,
    decision: str, # 'Approved' or 'Rejected'
    conditions: Optional[str] = None,
    tool_context: ToolContext
) -> Dict[str, Any]:
    """Records the underwriter's decision for a loan application.

    This tool updates the internal state based on human input received externally.

    Args:
        application_id: The ID of the loan application.
        decision: The underwriter's decision ('Approved' or 'Rejected').
        conditions: Optional conditions or reasons for the decision.
        tool_context: Provides access to session state.

    Returns:
        A dictionary indicating the result.
        Includes 'status': 'success' or 'error', and a message or error_message.
    """
    print(f"--- Tool: receive_underwriter_decision called for app ID: {application_id}, decision: {decision} ---")

    # --- INTERNAL STATE UPDATE BASED ON EXTERNAL INPUT ---
    # This logic updates the system state based on a human decision received from outside the core agent workflow.

    # Validate decision input
    if decision.lower() not in ['approved', 'rejected']:
         return {"status": "error", "error_message": "Invalid decision provided. Must be 'Approved' or 'Rejected'."}

    # Find the relevant application in state to ensure it matches the ID
    # In a real system, you'd likely match this against a database/LOS record, not just in-memory state.
    current_app_id_in_state = tool_context.state.get('current_application_id')

    if current_app_id_in_state != application_id:
         print(f"--- Tool Error: Application ID mismatch. State: {current_app_id_in_state}, Input: {application_id} ---")
         # This might indicate a state issue or incorrect tool call
         return {"status": "error", "error_message": f"Application ID mismatch. Current session is for {current_app_id_in_state}, but received decision for {application_id}."}


    # Update state with the decision and clear the awaiting flag
    tool_context.state['current_underwriting_status'] = decision.capitalize()
    tool_context.state['underwriting_conditions'] = conditions
    tool_context.state['awaiting_underwriter_input'] = False # Clear HILT flag
    print(f"--- Tool: Underwriter decision '{decision.capitalize()}' recorded for app ID {application_id} in state. ---")

    # Note: A real implementation might also call the LOS_UPDATE_STATUS_TOOL from *within* this tool
    # or rely on the subsequent agent in the workflow to check the state and update the LOS.
    # For this structure, the next agent will read the state and update the LOS.

    return {"status": "success", "message": f"Underwriter decision recorded: {decision.capitalize()}. Workflow can proceed."}

    # --- END INTERNAL STATE UPDATE ---


# Wrap the tool functions
UNDERWRITER_REVIEW_TOOL = FunctionTool(func=request_underwriter_review)
UNDERWRITER_DECISION_TOOL = FunctionTool(func=receive_underwriter_decision) # This tool would be called externally


# Define the Underwriting Review Agent workflow
# This agent requests the review and potentially waits/handles the outcome.
underwriting_review_agent = SequentialAgent(
    name="UnderwritingReviewAgent",
    model="gemini-2.0-flash", # Use an appropriate LLM to summarize and guide workflow
    description="Coordinates the human underwriter review process for hard money loans.",
    instruction="You are the Underwriting Review Agent. Your task is to facilitate human underwriter review."
                "First, use the 'request_underwriter_review' tool to create a review task."
                "Gather the necessary loan details summary from state (borrower, property address, loan amount, and crucial LTV from state['current_valuation_LTV']) for the tool arguments."
                "Inform the MLO that the application is sent for underwriter review and that the workflow is awaiting the human decision."
                "The underwriter's decision will be recorded in state['current_underwriting_status'] (set by the 'receive_underwriter_decision' tool called externally)."
                "After the review decision is recorded, check state['current_underwriting_status']."
                "If the status is 'Approved', update the loan status in the LOS to 'Underwriting Approved' using the 'update_loan_status' tool."
                "If the status is 'Rejected', update the loan status in the LOS to 'Underwriting Rejected' using the 'update_loan_status' tool, including state['underwriting_conditions'] as notes if available."
                "Report the final underwriting outcome (Approved or Rejected) to the MLO.",
    tools=[UNDERWRITER_REVIEW_TOOL, LOS_UPDATE_STATUS_TOOL], # Include tools needed for this stage
    sub_agents=[
         Agent( # Agent to trigger the review request
              name="ReviewRequestTrigger",
              model="gemini-1.0-pro", # Cheaper model for a simple tool call trigger
              instruction="Use the 'request_underwriter_review' tool with app ID from state['current_application_id'] and a summary of loan details including borrower, property address, loan amount, and especially the calculated LTV from state['current_valuation_LTV'].",
              tools=[UNDERWRITER_REVIEW_TOOL] # Only needs the tool to request review
         ),
         Agent( # Agent to check for the decision result after external input and update LOS
               name="DecisionCheckerAndUpdater",
               model="gemini-2.0-flash", # More capable model to interpret state and update LOS
               instruction="Check state['current_underwriting_status']. This state variable is updated by an external process using the 'receive_underwriter_decision' tool."
                           "If state['current_underwriting_status'] is 'Approved', update the loan status in the LOS to 'Underwriting Approved' for app ID from state['current_application_id'] using the 'update_loan_status' tool."
                           "If state['current_underwriting_status'] is 'Rejected', update the loan status in the LOS to 'Underwriting Rejected' for app ID from state['current_application_id'] using the 'update_loan_status' tool, including state['underwriting_conditions'] as notes if available."
                           "If state['current_underwriting_status'] is still 'Review Requested' or 'pending', inform the MLO you are still awaiting the underwriter's decision and the workflow cannot proceed yet.",
                tools=[LOS_UPDATE_STATUS_TOOL] # Need the LOS update tool here
         )
         # Note: A real HILT might need a LoopAgent here to wait for state['awaiting_underwriter_input'] to become False
         # or check state['current_underwriting_status'] to be non-pending.
         # For this SequentialAgent, the DecisionCheckerAndUpdater runs immediately after the request is sent.
         # To simulate waiting, the MLO/external system must manually call `receive_underwriter_decision`
         # and then potentially re-trigger the runner or send a message ("Any updates?") to the agent.
    ]
)

print("UnderwritingReviewAgent (Sequential workflow including HILT tools) defined.")
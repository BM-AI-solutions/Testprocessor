# --- FILE: hard_money_loan_processor/sub_agents/document_generation_agent.py ---

from google.adk.agents import Agent, SequentialAgent
from hard_money_loan_processor.tools.document_closing_tools import DOC_GEN_TOOL, ESIGN_SEND_TOOL
from hard_money_loan_processor.tools.loan_origination_tools import LOS_UPDATE_STATUS_TOOL
from typing import List

# Define the Document Generation and E-signature Agent workflow
document_generation_agent = SequentialAgent(
    name="DocumentGenerationAgent",
    model="gemini-2.0-flash", # Use an appropriate LLM to guide the process and summarize
    description="Handles generation of loan documents and sends them for e-signature.",
    instruction="You are the Document Generation Agent. Your task is to generate loan documents and send them for signature sequentially.",
    tools=[DOC_GEN_TOOL, ESIGN_SEND_TOOL, LOS_UPDATE_STATUS_TOOL], # Assign relevant tools needed by sub-agents or for direct use
    sub_agents=[
         Agent( # Agent to trigger document generation
              name="DocGenTrigger",
              model="gemini-1.0-pro", # Cheaper model for a simple trigger
              instruction="Use the 'generate_loan_documents' tool with app ID from state['current_application_id']. Report the result.",
              tools=[DOC_GEN_TOOL] # Only needs the document generation tool
         ),
         Agent( # Agent to update status after generation and trigger e-sign
              name="EsignSendTrigger",
              model="gemini-2.0-flash", # More capable model to handle transition and arguments
              instruction="Document generation is complete. Use the 'update_loan_status' tool to set status to 'Documents Generated' for app ID from state['current_application_id']."
                          "Then, use the 'send_docs_for_signature' tool with app ID from state['current_application_id'], the document list from state['generated_documents'], and borrower name from state['current_borrower_name']. Report the outcome of sending for signature.",
              tools=[LOS_UPDATE_STATUS_TOOL, ESIGN_SEND_TOOL] # Needs LOS update and E-sign send tools
         )
    ]
)

print("DocumentGenerationAgent (SequentialAgent) defined.")
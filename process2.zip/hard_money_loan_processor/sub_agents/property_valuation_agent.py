# --- FILE: hard_money_loan_processor/sub_agents/property_valuation_agent.py ---

from google.adk.agents import Agent, LoopAgent, SequentialAgent
from google.adk.events import Event, EventActions
from google.adk.agents.invocation_context import InvocationContext
from typing import List, AsyncGenerator, Dict, Any
from hard_money_loan_processor.tools.property_valuation_tools import PROPERTY_DETAILS_TOOL, VALUATION_REQUEST_TOOL, VALUATION_CHECK_TOOL
from hard_money_loan_processor.tools.loan_origination_tools import LOS_UPDATE_STATUS_TOOL
import time # Used in simulation examples, remove if not needed after real integration

# Agent to handle getting property details
property_details_agent = Agent(
    name="PropertyDetailsFetcher",
    model="gemini-2.0-flash",
    description="Retrieves basic property details using the property_details tool.",
    instruction="Use the 'get_property_details' tool to fetch details for the property address stored in state['current_property_address']. "
                "If the tool reports the property is not in California, update the loan status to 'Property Not in CA' using the LOS tool and escalate to stop the process. "
                "If the tool encounters an error other than CA check failure, update status to 'Property Details Failed' and escalate. "
                "If successful, update the loan status to 'Property Details Obtained' using the LOS tool.",
    tools=[PROPERTY_DETAILS_TOOL, LOS_UPDATE_STATUS_TOOL]
)

# Agent to request valuation
valuation_request_agent = Agent(
    name="ValuationRequester",
    model="gemini-2.0-flash",
    description="Requests property valuation using the request_valuation tool.",
    instruction="Use the 'request_valuation' tool with the application ID from state['current_application_id'] and property address from state['current_property_address']. "
                "If the tool reports status 'pending' or 'success', update the loan status to 'Valuation Requested' using the LOS tool. "
                "If the tool reports status 'error', update the loan status to 'Valuation Request Failed' and escalate.",
    tools=[VALUATION_REQUEST_TOOL, LOS_UPDATE_STATUS_TOOL]
)

# LlmAgent to check the status within the loop
# The check_valuation_status tool itself updates the state['current_valuation_status'] and state['current_valuation_LTV'].
# This agent's instruction guides the LLM to call the tool and interpret the state.
valuation_check_llm_agent = Agent(
    name="ValuationCheckLlmAgent",
    model="gemini-1.0-pro", # Cheaper model for simple check/read state task
    description="Checks the valuation status via tool and state.",
    instruction="Use the 'check_valuation_status' tool with the order ID in state['current_valuation_order_id']."
                "Analyze the tool's response and state['current_valuation_status']."
                "If state['current_valuation_status'] is 'Completed', report the valuation amount from state['current_valuation_amount'] and LTV from state['current_valuation_LTV'] to the MLO and indicate the task is done."
                "If state['current_valuation_status'] is 'Error', report the error message from the tool result and indicate the task failed."
                "If state['current_valuation_status'] is 'Pending', report the pending status and indicate that the check will be repeated.",
    tools=[VALUATION_CHECK_TOOL],
    # output_key="valuation_check_result" # Save check result to state if needed by later agents
)

# Custom Agent to decide whether to continue looping or escalate
# This agent contains the logic to read state and determine the loop flow.
class ValuationLoopDecider(Agent):
    def __init__(self, **kwargs):
         # No LLM model needed for this purely logic-based agent.
         super().__init__(name="ValuationLoopDecider", **kwargs)

    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[Event, None]:
        print(f"--- Custom Agent: {self.name} deciding loop status ---")
        # The valuation_check_llm_agent (the previous agent in the LoopAgent)
        # should have updated the 'current_valuation_status' in state.
        valuation_status = ctx.session.state.get('current_valuation_status')
        print(f"--- Custom Agent: Current valuation status in state: {valuation_status} ---")

        is_done = (valuation_status == 'Completed')
        is_failed = (valuation_status == 'Error') # Assume 'Error' means permanent failure

        if is_done:
            print(f"--- Custom Agent: Valuation completed. Escalating to exit loop. ---")
            # Yield an event that causes the LoopAgent to escalate/stop
            yield Event(author=self.name, actions=EventActions(escalate=True))
        elif is_failed:
            print(f"--- Custom Agent: Valuation failed. Escalating to exit loop. ---")
            # Yield an event that causes the LoopAgent to escalate/stop
            yield Event(author=self.name, actions=EventActions(escalate=True))
        else:
            # If still pending, yield nothing or a message to let the LoopAgent continue
            print(f"--- Custom Agent: Valuation still pending. Continuing loop. ---")
            # Optionally, yield a message to the user, but this might make the UI noisy if polling frequently.
            # yield Event(author=self.name, content={"message": f"Valuation status is still '{valuation_status}'. Waiting for update..."})
            # No specific action needed to continue; the absence of 'escalate' allows the loop to proceed.
            pass # Let the next iteration of the loop begin


# The LoopAgent itself that orchestrates the checking and deciding
valuation_status_loop = LoopAgent(
    name="ValuationStatusLoop",
    max_iterations=30, # Set a reasonable limit to avoid infinite loops in case of issues
    sub_agents=[
        # Sequence of agents within the loop:
        # 1. Call the check tool and update state (via LlmAgent)
        valuation_check_llm_agent,
        # 2. Read state and decide if the loop should stop (via Custom Agent)
        ValuationLoopDecider(name="ValuationLoopDecisionMaker") # Give custom agent a name
    ]
)

# The overall Property Valuation Agent workflow combines fetching, requesting, and looping
property_valuation_agent = SequentialAgent(
    name="PropertyValuationAgent",
    description="Manages the property valuation process, including fetching details, requesting appraisal, and tracking status.",
    sub_agents=[
        # Step 1: Get property details first
        property_details_agent,
        # Step 2: Request the valuation
        valuation_step_request,
        # Step 3: Loop to check status until complete or failed
        valuation_status_loop
    ]
)

print("PropertyValuationAgent (Sequential workflow including LoopAgent and Custom Agent) defined.")
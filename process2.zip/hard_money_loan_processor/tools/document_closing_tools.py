# --- FILE: hard_money_loan_processor/tools/document_closing_tools.py ---

from google.adk.tools import ToolContext, FunctionTool, LongRunningFunctionTool
from typing import Dict, Any, Optional, List
import os
import requests # Example library

# Define Tool functions for document generation and closing steps

def generate_loan_documents(
    application_id: str,
    tool_context: ToolContext
) -> Dict[str, Any]:
    """Generates standard loan documents based on the application data.

    This tool would interface with a document generation engine (e.g., pulling templates, merging data).

    Args:
        application_id: The ID of the loan application.
        tool_context: Provides access to session state.

    Returns:
        A dictionary containing the result.
        If successful, includes 'status': 'success', 'document_list': list[str], and message.
        If an error occurs, includes 'status': 'error', 'error_message': str.
    """
    print(f"--- Tool: generate_loan_documents called for app ID: {application_id} ---")

    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to a document generation service.
    # Example using 'requests' library

    docgen_api_url = os.environ.get("DOCGEN_API_URL")
    api_key = os.environ.get("DOCGEN_API_KEY")

    if not docgen_api_url or not api_key:
         return {"status": "error", "error_message": "Document Generation API URL or Key environment variable not set."}

    headers = {
        "Content-Type": "application/json",
        "X-API-Key": api_key
    }

    payload = {
        "applicationId": application_id,
        # Add other parameters required by your API, e.g., template IDs, data points
        # You might need to retrieve more loan details from state or LOS via get_loan_details if needed
    }

    try:
        # Example: Making a POST request to trigger document generation
        api_response = requests.post(f'{docgen_api_url}/generate', json=payload, headers=headers)
        api_response.raise_for_status() # Raise HTTPError

        response_data = api_response.json() # Assuming the API returns JSON

        # Extract the list of generated document names/IDs/links from the API response
        generated_docs_list = response_data.get("documentList") # Adjust key based on your API
        generation_status = response_data.get("status") # e.g., 'Completed', 'Pending'

        if generation_status != 'Completed' or not isinstance(generated_docs_list, list) or not generated_docs_list:
             print(f"--- Tool Error: Doc Gen API did not return completed status or document list: {generation_status} ---")
             error_msg = response_data.get("errorMessage", "Document generation failed.")
             return {"status": "error", "error_message": error_msg}


        # Store the list of documents in state
        tool_context.state['generated_documents'] = generated_docs_list
        tool_context.state['document_generation_status'] = 'Completed'

        print(f"--- Tool: Generated {len(generated_docs_list)} documents. ---")

        return {"status": "success", "document_list": generated_docs_list, "message": "Loan documents generated."}

    except requests.exceptions.RequestException as e:
        print(f"--- Tool Error: Document generation API request failed: {e} ---")
        return {"status": "error", "error_message": f"Failed to call Document Generation API: {e}"}
    except Exception as e:
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        return {"status": "error", "error_message": f"An unexpected error occurred during document generation API call: {e}"}

    # --- END REAL API INTEGRATION ---


def send_docs_for_signature(
    application_id: str,
    document_list: List[str],
    borrower_name: str, # Assuming borrower name is enough for e-sign target, might need email/ID
    tool_context: ToolContext
) -> Dict[str, Any]:
    """Sends generated loan documents for electronic signature.

    This tool would interface with an e-signature platform API (e.g., DocuSign, Adobe Sign).

    Args:
        application_id: The ID of the loan application.
        document_list: A list of document names/IDs to send.
        borrower_name: The name of the borrower to send to.
        tool_context: Provides access to session state.

    Returns:
        A dictionary containing the result.
        If successful, includes 'status': 'pending', 'esign_transaction_id': str, and message.
        If an error occurs, includes 'status': 'error', 'error_message': str.
    """
    print(f"--- Tool: send_docs_for_signature called for app ID: {application_id}, docs: {document_list} ---")

    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to an e-signature platform.
    # Example using 'requests' library

    esign_api_url = os.environ.get("ESIGN_API_URL")
    api_key = os.environ.get("ESIGN_API_KEY")

    if not esign_api_url or not api_key:
         return {"status": "error", "error_message": "E-signature API URL or Key environment variable not set."}

    headers = {
        "Content-Type": "application/json",
        "X-API-Key": api_key
    }

    payload = {
        "applicationId": application_id,
        "documents": document_list, # Pass the list of documents to the API
        "recipientName": borrower_name,
        # Add other parameters required by your API, e.g., recipient email, signing order
    }

    try:
        # Example: Making a POST request to create and send an e-sign transaction
        api_response = requests.post(f'{esign_api_url}/transactions', json=payload, headers=headers)
        api_response.raise_for_status() # Raise HTTPError

        response_data = api_response.json() # Assuming the API returns JSON

        esign_transaction_id = response_data.get("transactionId") # Adjust key based on your API
        # status_from_api = response_data.get("status") # Your API might return 'Sent', 'Pending', etc.

        if not esign_transaction_id:
             print("--- Tool Error: E-sign API response missing transaction ID ---")
             return {"status": "error", "error_message": "E-signature API response missing transaction ID or unexpected format."}

        # Store the transaction ID and initial status in state
        tool_context.state['current_esign_transaction_id'] = esign_transaction_id
        # Assume the initial status is 'Sent for Signature' or use status_from_api
        tool_context.state['current_esign_status'] = 'Sent for Signature'

        print(f"--- Tool: E-signature transaction sent with ID {esign_transaction_id}. ---")

        # Return status 'pending' as signature is an asynchronous process
        return {"status": "pending", "esign_transaction_id": esign_transaction_id, "message": f"Documents sent for signature to {borrower_name}. Transaction ID: {esign_transaction_id}. Awaiting completion."}

    except requests.exceptions.RequestException as e:
        print(f"--- Tool Error: E-sign send API request failed: {e} ---")
        return {"status": "error", "error_message": f"Failed to send documents for signature via API: {e}"}
    except Exception as e:
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        return {"status": "error", "error_message": f"An unexpected error occurred during e-sign send API call: {e}"}

    # --- END REAL API INTEGRATION ---

# This could be a LongRunningFunctionTool if polling for signature completion is done inside
# the tool function itself, but here we'll implement it as a simple FunctionTool
# to be called repeatedly by a LoopAgent.
def check_signature_status(
    esign_transaction_id: str,
    tool_context: ToolContext
) -> Dict[str, Any]:
    """Checks the status of an e-signature transaction.

    This tool would poll an e-signature platform API for the status of a transaction.

    Args:
        esign_transaction_id: The ID of the e-signature transaction.
        tool_context: Provides access to session state.

    Returns:
        A dictionary containing the result.
        Includes 'status': 'Completed', 'Pending', 'Declined', 'Expired', 'Error', or another status from the API.
        If 'Completed', might include 'completion_date'.
        If 'Error', includes 'error_message': str.
        If 'Pending', includes 'message': str about waiting.
    """
    print(f"--- Tool: check_signature_status called for transaction ID: {esign_transaction_id} ---")

    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to check e-sign status.
    # Example using 'requests' library

    esign_api_url = os.environ.get("ESIGN_API_URL")
    api_key = os.environ.get("ESIGN_API_KEY")

    if not esign_api_url or not api_key:
         return {"status": "error", "error_message": "E-signature API URL or Key environment variable not set."}

    headers = {
        "X-API-Key": api_key
    }

    try:
        # Example: Making a GET request to check transaction status
        api_response = requests.get(f'{esign_api_url}/transactions/{esign_transaction_id}/status', headers=headers)
        api_response.raise_for_status() # Raise HTTPError

        response_data = api_response.json() # Assuming the API returns JSON status/results

        current_status = response_data.get("status") # Adjust key based on your API
        completion_date = response_data.get("completionDate") # May be present if completed

        if not current_status:
             print("--- Tool Error: E-sign API response missing status ---")
             return {"status": "error", "error_message": "E-signature API response missing status or unexpected format."}

        # Update status in state
        tool_context.state['current_esign_status'] = current_status
        print(f"--- Tool: Updated state['current_esign_status'] to {current_status} ---")

        if current_status == 'Completed': # Match status string from your API
            print(f"--- Tool: E-signature completed for transaction {esign_transaction_id}. ---")
            return {"status": "success", "esign_status": current_status, "completion_date": completion_date}

        elif current_status in ['Declined', 'Expired', 'Error']: # Match failure statuses from your API
             error_msg = response_data.get("errorMessage", f"E-signature failed with status: {current_status}.")
             print(f"--- Tool: E-signature failed ({current_status}). Error: {error_msg} ---")
             return {"status": "error", "esign_status": current_status, "error_message": error_msg}

        else: # Status is still pending or another non-terminal state
            print(f"--- Tool: E-signature still {current_status} for transaction {esign_transaction_id} ---")
            # The LoopAgent logic will decide whether to continue polling based on this status
            return {"status": current_status, "message": f"E-signature transaction {esign_transaction_id} is still '{current_status}'."}


    except requests.exceptions.RequestException as e:
        print(f"--- Tool Error: Check e-sign status API request failed: {e} ---")
        return {"status": "error", "error_message": f"Failed to check e-signature status via API: {e}"}
    except Exception as e:
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        return {"status": "error", "error_message": f"An unexpected error occurred during e-sign status check API call: {e}"}
    # --- END REAL API INTEGRATION ---


def fund_loan(
     application_id: str,
     tool_context: ToolContext
) -> Dict[str, Any]:
     """Initiates the funding process for a closed loan.

     This tool would interface with a banking, escrow, or funding system API.

     Args:
        application_id: The ID of the loan application.
        tool_context: Provides access to session state.

     Returns:
        A dictionary containing the result.
        Includes 'status': 'success' or 'error', and a message or error_message.
     """
     print(f"--- Tool: fund_loan called for app ID: {application_id} ---")

     # --- REAL API INTEGRATION GOES HERE ---
     # Replace the following placeholder logic with actual API calls to initiate funding.
     # Example using 'requests' library

     funding_api_url = os.environ.get("FUNDING_API_URL")
     api_key = os.environ.get("FUNDING_API_KEY")

     if not funding_api_url or not api_key:
          return {"status": "error", "error_message": "Funding API URL or Key environment variable not set."}

     headers = {
         "Content-Type": "application/json",
         "X-API-Key": api_key
     }

     payload = {
         "applicationId": application_id,
         # Add other parameters required by your API, e.g., funding amount (get from state), bank details
         # You might need to retrieve funding amount from state['current_loan_amount_requested']
     }

     try:
         # Example: Making a POST request to initiate funding
         api_response = requests.post(f'{funding_api_url}/initiate', json=payload, headers=headers)
         api_response.raise_for_status() # Raise HTTPError

         # Assuming successful initiation returns a simple confirmation or transaction ID
         response_data = api_response.json() # Uncomment if your API returns JSON

         # Assume success if no HTTP error was raised
         tool_context.state['current_funding_status'] = 'Initiated'
         print(f"--- Tool: Funding initiated for app ID {application_id}. ---")
         # Optionally store a funding transaction ID if returned by the API
         # tool_context.state['current_funding_transaction_id'] = response_data.get("transactionId")


         return {"status": "success", "message": "Funding process initiated."}

     except requests.exceptions.RequestException as e:
         print(f"--- Tool Error: Fund loan API request failed: {e} ---")
         return {"status": "error", "error_message": f"Failed to initiate funding via API: {e}"}
     except Exception as e:
         print(f"--- Tool Error: An unexpected error occurred: {e} ---")
         return {"status": "error", "error_message": f"An unexpected error occurred during funding API call: {e}"}

     # --- END REAL API INTEGRATION ---


# Wrap the tool functions
DOC_GEN_TOOL = FunctionTool(func=generate_loan_documents)
ESIGN_SEND_TOOL = FunctionTool(func=send_docs_for_signature)
ESIGN_CHECK_TOOL = FunctionTool(func=check_signature_status)
FUND_LOAN_TOOL = FunctionTool(func=fund_loan)

print("Document and Closing Tool functions defined and wrapped.")
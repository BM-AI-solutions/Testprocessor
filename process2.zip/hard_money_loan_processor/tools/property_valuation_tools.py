# --- FILE: hard_money_loan_processor/tools/property_valuation_tools.py ---

from google.adk.tools import ToolContext, FunctionTool
from typing import Dict, Any, Optional
import os
import requests # Example library for making HTTP requests

# Define Tool functions representing interactions with a hypothetical Property Valuation API

def get_property_details(
    property_address: str,
    tool_context: ToolContext # Allows access to session state
) -> Dict[str, Any]:
    """Retrieves basic property details for a given address from a property database.

    Args:
        property_address: The full address of the property.
        tool_context: Provides access to session state.

    Returns:
        A dictionary containing the result.
        If successful, includes 'status': 'success', 'details': dict with basic property info (e.g., 'county', 'property_type', 'lot_size').
        If an error occurs, includes 'status': 'error', 'error_message': str.
        Includes California verification.
    """
    print(f"--- Tool: get_property_details called for address: {property_address} ---")

    # Simulate California check - crucial for CA MLO specialty
    if "CA" not in property_address.upper() and "CALIFORNIA" not in property_address.upper():
         print("--- Tool: Property is not in California. ---")
         tool_context.state['property_state_check'] = 'failed' # Mark failure in state
         return {"status": "error", "error_message": f"Property address '{property_address}' does not appear to be in California. This tool only supports CA properties."}

    print("--- Tool: Property appears to be in California. ---")
    tool_context.state['property_state_check'] = 'passed' # Mark success in state


    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to a property data provider.
    # Example using 'requests' library

    property_api_url = os.environ.get("PROPERTY_API_URL")
    api_key = os.environ.get("PROPERTY_API_KEY")

    if not property_api_url or not api_key:
         return {"status": "error", "error_message": "Property API URL or Key environment variable not set."}

    headers = {
        "X-API-Key": api_key
    }

    params = {
        "address": property_address
        # Add other parameters required by your API, e.g., state, county
    }

    try:
        # Example: Making a GET request for property details
        api_response = requests.get(f'{property_api_url}/details', params=params, headers=headers)
        api_response.raise_for_status() # Raise HTTPError

        details = api_response.json() # Assuming the API returns JSON details

        # Validate and extract relevant details from the API response
        # You might need to map API response keys to your desired state keys
        if not details: # Basic check
             print("--- Tool Error: Property API returned empty details ---")
             return {"status": "error", "error_message": f"Property details not found for '{property_address}'."}

        # Store relevant details in state for later steps
        tool_context.state['current_property_details'] = {
            "address": details.get("formattedAddress", property_address), # Use formatted address if available
            "county": details.get("county"),
            "property_type": details.get("propertyType"),
            "lot_size_sqft": details.get("lotSizeSqft"),
            "year_built": details.get("yearBuilt"),
            # Add other fields as needed based on your API response
        }
        print(f"--- Tool: Stored property details for {property_address} in state ---")

        return {"status": "success", "details": details} # Return raw or processed details

    except requests.exceptions.RequestException as e:
        print(f"--- Tool Error: Property API request failed: {e} ---")
        return {"status": "error", "error_message": f"Failed to retrieve property details via API: {e}"}
    except Exception as e:
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        return {"status": "error", "error_message": f"An unexpected error occurred during property details API call: {e}"}

    # --- END REAL API INTEGRATION ---


def request_valuation(
    application_id: str,
    property_address: str,
    tool_context: ToolContext # Allows access to session state
) -> Dict[str, Any]:
    """Submits a request for property valuation (e.g., BPO or appraisal) via an external service.

    Args:
        application_id: The associated loan application ID.
        property_address: The address of the property to be valued.
        tool_context: Provides access to session state.

    Returns:
        A dictionary containing the result.
        If successful, includes 'status': 'pending', 'valuation_order_id': str, and a message.
        If an error occurs, includes 'status': 'error', 'error_message': str.
    """
    print(f"--- Tool: request_valuation called for app ID {application_id}, address: {property_address} ---")

    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to a valuation service.
    # Example using 'requests' library

    valuation_api_url = os.environ.get("VALUATION_API_URL")
    api_key = os.environ.get("VALUATION_API_KEY")

    if not valuation_api_url or not api_key:
         return {"status": "error", "error_message": "Valuation API URL or Key environment variable not set."}

    headers = {
        "Content-Type": "application/json",
        "X-API-Key": api_key
    }

    payload = {
        "applicationId": application_id,
        "propertyAddress": property_address,
        # Add other parameters required by your API, e.g., type of valuation (BPO/Appraisal)
    }

    try:
        # Example: Making a POST request to order a valuation
        api_response = requests.post(f'{valuation_api_url}/orders', json=payload, headers=headers)
        api_response.raise_for_status() # Raise HTTPError

        response_data = api_response.json() # Assuming the API returns JSON

        valuation_order_id = response_data.get("orderId") # Adjust key based on your API response structure
        # status_from_api = response_data.get("status") # Your API might return 'Pending' immediately

        if not valuation_order_id:
             print("--- Tool Error: Valuation API response missing order ID ---")
             return {"status": "error", "error_message": "Valuation API response missing order ID or unexpected format."}

        # Store the order ID and initial status in state
        tool_context.state['current_valuation_order_id'] = valuation_order_id
        # Assume the initial status is pending based on the tool's return type
        tool_context.state['current_valuation_status'] = 'Requested' # Or use status_from_api if provided

        print(f"--- Tool: Stored valuation order ID {valuation_order_id} in state ---")

        # Return status as 'pending' to indicate the task is not instantly complete
        return {"status": "pending", "valuation_order_id": valuation_order_id, "message": f"Property valuation requested with order ID {valuation_order_id}. Please allow time for processing."}

    except requests.exceptions.RequestException as e:
        print(f"--- Tool Error: Valuation API request failed: {e} ---")
        return {"status": "error", "error_message": f"Failed to request valuation via API: {e}"}
    except Exception as e:
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        return {"status": "error", "error_message": f"An unexpected error occurred during valuation request API call: {e}"}

    # --- END REAL API INTEGRATION ---


def check_valuation_status(
    valuation_order_id: str,
    tool_context: ToolContext
) -> Dict[str, Any]:
    """Checks the status and results of a property valuation order.

    Args:
        valuation_order_id: The ID of the valuation order.
        tool_context: Provides access to session state.

    Returns:
        A dictionary containing the result.
        Includes 'status': 'Completed', 'Pending', 'Error', or another status from the API.
        If 'Completed', includes 'valuation_result': dict with value, report link, etc.
        If 'Error', includes 'error_message': str.
        If 'Pending', includes 'message': str about waiting.
    """
    print(f"--- Tool: check_valuation_status called for order ID: {valuation_order_id} ---")

    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to check status.
    # Example using 'requests' library

    valuation_api_url = os.environ.get("VALUATION_API_URL")
    api_key = os.environ.get("VALUATION_API_KEY")

    if not valuation_api_url or not api_key:
         return {"status": "error", "error_message": "Valuation API URL or Key environment variable not set."}

    headers = {
        "X-API-Key": api_key
    }

    try:
        # Example: Making a GET request to check order status
        api_response = requests.get(f'{valuation_api_url}/orders/{valuation_order_id}/status', headers=headers)
        api_response.raise_for_status() # Raise HTTPError

        response_data = api_response.json() # Assuming the API returns JSON status/results

        current_status = response_data.get("status") # Adjust key based on your API
        # valuation_details = response_data.get("details") # May include value, link, etc.

        if not current_status:
             print("--- Tool Error: Valuation API response missing status ---")
             return {"status": "error", "error_message": "Valuation API response missing status or unexpected format."}

        # Update status in state
        tool_context.state['current_valuation_status'] = current_status
        print(f"--- Tool: Updated state['current_valuation_status'] to {current_status} ---")

        if current_status == 'Completed': # Match status string from your API
            valuation_amount = response_data.get("valuationAmount") # Extract value from API response
            report_link = response_data.get("reportLink") # Extract report link

            if valuation_amount is None:
                 print("--- Tool Error: Valuation completed but amount is missing ---")
                 # Consider if this is an error or just incomplete data
                 return {"status": "error", "error_message": "Valuation completed but amount is missing from API response."}

            # Retrieve loan amount from state to calculate LTV
            loan_amount = tool_context.state.get('current_loan_amount_requested', 0)
            ltv = (loan_amount / valuation_amount) * 100 if valuation_amount else 0
            tool_context.state['current_valuation_amount'] = valuation_amount
            tool_context.state['current_valuation_LTV'] = round(ltv, 2) # Calculate and store LTV

            valuation_result = {
                 "status": current_status,
                 "valuation_amount": valuation_amount,
                 "report_link": report_link,
                 "calculated_ltv": round(ltv, 2) # Include LTV in the tool result
                 # Include any other relevant details from the API response
            }
            print(f"--- Tool: Valuation completed. Value: {valuation_amount}, LTV: {ltv:.2f}% ---")
            return {"status": "success", "valuation_result": valuation_result} # Return status 'success' for completion

        elif current_status == 'Error': # Match error status string from your API
            error_msg = response_data.get("errorMessage", "Valuation failed.")
            print(f"--- Tool: Valuation failed. Error: {error_msg} ---")
            return {"status": "error", "error_message": error_msg}

        else: # Status is still pending or another non-terminal state
            print(f"--- Tool: Valuation status is still {current_status} ---")
            # The LoopAgent logic will decide whether to continue polling based on this status
            return {"status": current_status, "message": f"Valuation order {valuation_order_id} is still '{current_status}'."}


    except requests.exceptions.RequestException as e:
        print(f"--- Tool Error: Check valuation status API request failed: {e} ---")
        return {"status": "error", "error_message": f"Failed to check valuation status via API: {e}"}
    except Exception as e:
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        return {"status": "error", "error_message": f"An unexpected error occurred during status check API call: {e}"}
    # --- END REAL API INTEGRATION ---


# Wrap the tool functions
PROPERTY_DETAILS_TOOL = FunctionTool(func=get_property_details)
VALUATION_REQUEST_TOOL = FunctionTool(func=request_valuation)
VALUATION_CHECK_TOOL = FunctionTool(func=check_valuation_status)

print("Property Valuation Tool functions defined and wrapped.")
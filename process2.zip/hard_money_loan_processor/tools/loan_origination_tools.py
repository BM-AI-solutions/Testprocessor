# --- FILE: hard_money_loan_processor/tools/loan_origination_tools.py ---

from google.adk.tools import ToolContext, FunctionTool
from typing import Dict, Any, Optional
import os
import requests # Example library for making HTTP requests

# Define Tool functions representing interactions with a hypothetical Loan Origination System (LOS) API

def create_loan_application(
    borrower_name: str,
    property_address: str,
    loan_amount_requested: float,
    loan_type: str, # Expected to be 'Hard Money'
    tool_context: ToolContext # Allows access to session state
) -> Dict[str, Any]:
    """Creates a new loan application record in the Loan Origination System (LOS).

    Args:
        borrower_name: The full name of the borrower (individual or entity).
        property_address: The full address of the property being used as collateral.
        loan_amount_requested: The dollar amount the borrower is requesting.
        loan_type: The type of loan being processed (should be 'Hard Money').
        tool_context: Provides access to session state for storing the new application ID.

    Returns:
        A dictionary containing the result of the operation.
        If successful, includes 'status': 'success' and 'application_id': str.
        If an error occurs, includes 'status': 'error' and 'error_message': str.
    """
    print(f"--- Tool: create_loan_application called for {borrower_name}, {property_address} ---")

    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to your LOS.
    # Example using 'requests' library (you need to install it: pip install requests)

    los_api_url = os.environ.get("LOS_API_URL") # Get API URL from environment variable
    if not los_api_url:
        return {"status": "error", "error_message": "LOS_API_URL environment variable not set."}

    # Assuming your LOS API requires authentication, e.g., an API Key in a header
    api_key = os.environ.get("LOS_API_KEY") # Get API key from environment
    if not api_key:
         return {"status": "error", "error_message": "LOS_API_KEY environment variable not set."}

    headers = {
        "Content-Type": "application/json",
        "X-API-Key": api_key # Replace with actual header name if different
    }

    payload = {
        "borrowerName": borrower_name,
        "propertyAddress": property_address,
        "loanAmountRequested": loan_amount_requested,
        "loanType": loan_type,
        # Add any other required data for your LOS endpoint
    }

    try:
        # Example: Making a POST request to the LOS API
        api_response = requests.post(f'{los_api_url}/applications', json=payload, headers=headers)
        api_response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)

        response_data = api_response.json() # Assuming the API returns JSON data

        # Extract the new application ID from the API response
        application_id = response_data.get("applicationId") # Adjust key based on your API response structure

        if not application_id:
            # Handle case where API call was successful but response format is unexpected
            print("--- Tool Error: LOS API response missing application ID ---")
            return {"status": "error", "error_message": "LOS API response missing application ID or unexpected format."}

        # Store the application ID and other initial details in session state using tool_context
        tool_context.state['current_application_id'] = application_id
        tool_context.state['current_loan_type'] = loan_type # Store loan type in state
        tool_context.state['current_borrower_name'] = borrower_name
        tool_context.state['current_property_address'] = property_address
        tool_context.state['current_loan_amount_requested'] = loan_amount_requested
        print(f"--- Tool: Stored application ID {application_id} and details in state ---")

        return {"status": "success", "application_id": application_id, "message": f"Loan application created with ID {application_id}."}

    except requests.exceptions.RequestException as e:
        # Handle network errors, timeouts, bad HTTP status codes
        print(f"--- Tool Error: LOS API request failed: {e} ---")
        return {"status": "error", "error_message": f"Failed to call LOS API: {e}"}
    except Exception as e:
        # Catch any other unexpected errors during processing
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        return {"status": "error", "error_message": f"An unexpected error occurred during API call: {e}"}

    # --- END REAL API INTEGRATION ---


def update_loan_status(
    application_id: str,
    new_status: str,
    notes: Optional[str] = None,
    tool_context: ToolContext # Allows access to session state
) -> Dict[str, Any]:
    """Updates the status of an existing loan application in the LOS.

    Args:
        application_id: The ID of the loan application.
        new_status: The new status to set (e.g., 'Intake Complete', 'Valuation Requested', 'Approved', 'Closed').
        notes: Optional notes to add to the status update.
        tool_context: Provides access to session state.

    Returns:
        A dictionary containing the result.
        Includes 'status': 'success' or 'error', and a message or error_message.
    """
    print(f"--- Tool: update_loan_status called for app ID {application_id}, status: {new_status} ---")

    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to update status in your LOS.
    # Example using 'requests' library

    los_api_url = os.environ.get("LOS_API_URL") # Get API URL from environment variable
    api_key = os.environ.get("LOS_API_KEY") # Get API key from environment

    if not los_api_url or not api_key:
         return {"status": "error", "error_message": "LOS API URL or Key environment variable not set."}

    headers = {
        "Content-Type": "application/json",
        "X-API-Key": api_key
    }

    payload = {
        "status": new_status,
        "notes": notes,
        # Add any other required data for status update
    }

    try:
        # Example: Making a PUT request to update the status
        api_response = requests.put(f'{los_api_url}/applications/{application_id}/status', json=payload, headers=headers)
        api_response.raise_for_status() # Raise HTTPError

        # Assuming successful update returns a simple confirmation or the updated record
        # response_data = api_response.json() # Uncomment if your API returns JSON

        # Update status in state upon successful API call
        tool_context.state['current_application_status'] = new_status
        print(f"--- Tool: Updated status for app ID {application_id} to {new_status} in state ---")

        return {"status": "success", "message": f"Status for application {application_id} updated to '{new_status}'."}

    except requests.exceptions.RequestException as e:
        print(f"--- Tool Error: Status update API request failed: {e} ---")
        return {"status": "error", "error_message": f"Failed to update loan status via LOS API: {e}"}
    except Exception as e:
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        return {"status": "error", "error_message": f"An unexpected error occurred during status update API call: {e}"}

    # --- END REAL API INTEGRATION ---

def get_loan_details(
    application_id: str,
    tool_context: ToolContext # Allows access to session state
) -> Dict[str, Any]:
    """Retrieves detailed information for a loan application from the LOS.

    Args:
        application_id: The ID of the loan application.
        tool_context: Provides access to session state.

    Returns:
        A dictionary containing the loan details.
        Includes 'status': 'success' or 'error'.
        If 'success', includes 'details': dict with relevant loan data.
        If 'error', includes 'error_message': str.
    """
    print(f"--- Tool: get_loan_details called for app ID {application_id} ---")

    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to retrieve details from your LOS.
    # Example using 'requests' library

    los_api_url = os.environ.get("LOS_API_URL") # Get API URL from environment variable
    api_key = os.environ.get("LOS_API_KEY") # Get API key from environment

    if not los_api_url or not api_key:
         return {"status": "error", "error_message": "LOS API URL or Key environment variable not set."}

    headers = {
        "X-API-Key": api_key
    }

    try:
        # Example: Making a GET request for loan details
        api_response = requests.get(f'{los_api_url}/applications/{application_id}', headers=headers)
        api_response.raise_for_status() # Raise HTTPError

        details = api_response.json() # Assuming the API returns JSON details

        # Optional: Update state with potentially richer details from the LOS if needed
        # tool_context.state['current_loan_details_from_los'] = details

        print(f"--- Tool: Retrieved details for app ID {application_id} ---")
        return {"status": "success", "details": details}

    except requests.exceptions.RequestException as e:
        # Handle network errors, timeouts, bad HTTP status codes (e.g., 404 Not Found)
        print(f"--- Tool Error: Get loan details API request failed: {e} ---")
        # Check for specific errors like 404 to return 'not found' status
        if api_response and api_response.status_code == 404:
             return {"status": "error", "error_message": f"Loan application with ID {application_id} not found in LOS."}
        else:
             return {"status": "error", "error_message": f"Failed to retrieve loan details via LOS API: {e}"}
    except Exception as e:
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        return {"status": "error", "error_message": f"An unexpected error occurred during get details API call: {e}"}

    # --- END REAL API INTEGRATION ---


# Wrap the tool functions for use in ADK Agents
LOS_CREATE_TOOL = FunctionTool(func=create_loan_application)
LOS_UPDATE_STATUS_TOOL = FunctionTool(func=update_loan_status)
LOS_GET_DETAILS_TOOL = FunctionTool(func=get_loan_details)

print("LOS Tool functions defined and wrapped.")
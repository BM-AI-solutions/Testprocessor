# --- FILE: hard_money_loan_processor/tools/borrower_qualification_tools.py ---

from google.adk.tools import ToolContext, FunctionTool
from typing import Dict, Any, Optional
import os
import requests # Example library

# Define Tool function for borrower qualification (less emphasis on credit for hard money)

def check_borrower_basic_info(
    borrower_name: str,
    borrower_type: str, # e.g., 'Individual', 'LLC', 'Corporation', 'Partnership'
    tool_context: ToolContext # Allows access to session state
) -> Dict[str, Any]:
    """Performs basic checks on borrower information.

    This tool would likely interface with a CRM or identity verification service
    to validate borrower type, check for basic entity registration, or perform
    simple KYC/AML checks.

    Args:
        borrower_name: The name of the borrower.
        borrower_type: The legal structure of the borrower.
        tool_context: Provides access to session state.

    Returns:
        A dictionary containing the result.
        Includes 'status': 'success' or 'error', and relevant messages.
    """
    print(f"--- Tool: check_borrower_basic_info called for {borrower_name} ({borrower_type}) ---")

    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to check borrower info.
    # Example using 'requests' library

    borrower_api_url = os.environ.get("BORROWER_API_URL") # e.g., Identity verification service
    api_key = os.environ.get("BORROWER_API_KEY")

    if not borrower_api_url or not api_key:
         return {"status": "error", "error_message": "Borrower API URL or Key environment variable not set."}

    headers = {
        "Content-Type": "application/json",
        "X-API-Key": api_key
    }

    # Basic validation of borrower type based on known types in the system
    valid_types = ['individual', 'llc', 'corporation', 'partnership']
    if borrower_type.lower() not in valid_types:
        tool_context.state['borrower_basic_check_status'] = 'Failed: Invalid Type'
        return {"status": "error", "error_message": f"Borrower type '{borrower_type}' is not recognized. Valid types are: {', '.join(valid_types)}."}


    payload = {
        "borrowerName": borrower_name,
        "borrowerType": borrower_type,
        # Add other parameters required by your API, e.g., address for identity match
    }

    try:
        # Example: Making a POST request to check basic info
        api_response = requests.post(f'{borrower_api_url}/basic-check', json=payload, headers=headers)
        api_response.raise_for_status() # Raise HTTPError

        response_data = api_response.json() # Assuming the API returns JSON

        check_status = response_data.get("status") # e.g., 'Passed', 'Failed'
        details = response_data.get("details", {}) # Optional details from API

        if check_status == 'Passed': # Match status string from your API
            tool_context.state['borrower_basic_check_status'] = 'Passed'
            tool_context.state['current_borrower_type'] = borrower_type # Store type in state
            # Store other relevant details from 'details' if needed
            print("--- Tool: Borrower basic check passed. ---")
            return {"status": "success", "message": f"Basic info check passed for {borrower_name}.", "details": details}
        elif check_status == 'Failed': # Match status string from your API
             failure_reason = details.get("reason", "Details did not verify.")
             tool_context.state['borrower_basic_check_status'] = f'Failed: {failure_reason}'
             print(f"--- Tool: Borrower basic check failed: {failure_reason} ---")
             return {"status": "error", "error_message": f"Basic info check failed for {borrower_name}: {failure_reason}"}
        else:
             # Handle unexpected API status values
             print(f"--- Tool Error: Borrower API returned unexpected status: {check_status} ---")
             tool_context.state['borrower_basic_check_status'] = f'Error: Unexpected API status ({check_status})'
             return {"status": "error", "error_message": f"Unexpected status from Borrower API: {check_status}"}


    except requests.exceptions.RequestException as e:
        print(f"--- Tool Error: Borrower basic info API request failed: {e} ---")
        tool_context.state['borrower_basic_check_status'] = 'Error: API Failed'
        return {"status": "error", "error_message": f"Failed to call Borrower Basic Info API: {e}"}
    except Exception as e:
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        tool_context.state['borrower_basic_check_status'] = 'Error: Unexpected Exception'
        return {"status": "error", "error_message": f"An unexpected error occurred during basic info API call: {e}"}
    # --- END REAL API INTEGRATION ---


def run_limited_credit_check(
    borrower_name: str,
    tool_context: ToolContext
) -> Dict[str, Any]:
    """Runs a limited credit/background check.

    For hard money, this might focus on liens, bankruptcies, or judgments rather than FICO score.
    This tool would integrate with credit bureaus or specialized background check services.

    Args:
        borrower_name: The name of the borrower.
        tool_context: Provides access to session state.

    Returns:
        A dictionary containing the result.
        Includes 'status': 'success' or 'error'.
        If 'success', includes 'report_summary': str.
        If 'error', includes 'error_message': str.
    """
    print(f"--- Tool: run_limited_credit_check called for {borrower_name} ---")

    # --- REAL API INTEGRATION GOES HERE ---
    # Replace the following placeholder logic with actual API calls to a credit/background check service.
    # Example using 'requests' library

    credit_api_url = os.environ.get("CREDIT_API_URL") # e.g., LexisNexis, specific credit bureau
    api_key = os.environ.get("CREDIT_API_KEY")

    if not credit_api_url or not api_key:
         return {"status": "error", "error_message": "Credit API URL or Key environment variable not set."}

    headers = {
        "Content-Type": "application/json",
        "X-API-Key": api_key
    }

    payload = {
        "borrowerName": borrower_name,
        # Add other parameters required by your API, e.g., DOB, address
    }

    try:
        # Example: Making a POST request to run a limited check
        api_response = requests.post(f'{credit_api_url}/limited-check', json=payload, headers=headers)
        api_response.raise_for_status() # Raise HTTPError

        response_data = api_response.json() # Assuming the API returns JSON

        check_status = response_data.get("status") # e.g., 'Completed', 'Failed'
        report_summary = response_data.get("summary") # e.g., "No major liens..."
        details = response_data.get("details", {}) # More granular data

        if check_status == 'Completed': # Match status string from your API
            tool_context.state['borrower_credit_check_status'] = 'Completed'
            tool_context.state['borrower_credit_report_summary'] = report_summary
            # Store details if needed
            print("--- Tool: Credit check completed. ---")
            return {"status": "success", "report_summary": report_summary, "details": details}
        elif check_status == 'Failed': # Match status string from your API
             failure_reason = response_data.get("reason", "Check failed.")
             tool_context.state['borrower_credit_check_status'] = f'Failed: {failure_reason}'
             print(f"--- Tool: Credit check failed: {failure_reason} ---")
             return {"status": "error", "error_message": f"Limited credit check failed for {borrower_name}: {failure_reason}"}
        else:
             # Handle unexpected API status values
             print(f"--- Tool Error: Credit API returned unexpected status: {check_status} ---")
             tool_context.state['borrower_credit_check_status'] = f'Error: Unexpected API status ({check_status})'
             return {"status": "error", "error_message": f"Unexpected status from Credit API: {check_status}"}


    except requests.exceptions.RequestException as e:
        print(f"--- Tool Error: Credit check API request failed: {e} ---")
        tool_context.state['borrower_credit_check_status'] = 'Error: API Failed'
        return {"status": "error", "error_message": f"Failed to call Credit Check API: {e}"}
    except Exception as e:
        print(f"--- Tool Error: An unexpected error occurred: {e} ---")
        tool_context.state['borrower_credit_check_status'] = 'Error: Unexpected Exception'
        return {"status": "error", "error_message": f"An unexpected error occurred during credit check API call: {e}"}

    # --- END REAL API INTEGRATION ---


# Wrap the tool functions
BORROWER_BASIC_CHECK_TOOL = FunctionTool(func=check_borrower_basic_info)
LIMITED_CREDIT_CHECK_TOOL = FunctionTool(func=run_limited_credit_check)

print("Borrower Qualification Tool functions defined and wrapped.")
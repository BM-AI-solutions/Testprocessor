# Hard Money Loan Processor Multi-Agent System

This project demonstrates a Multi-Agent System (MAS) built using the Google Agent Development Kit (ADK) to automate the key stages of a hard money loan processing workflow in California.

The MAS is structured as a hierarchy of agents, coordinated by a root `SequentialAgent`, with specialized sub-agents handling specific tasks like intake, property valuation, borrower qualification, underwriting review, document generation, and closing. External system interactions (Loan Origination System, Valuation Service, E-signature Platform, Funding System) are represented by ADK `FunctionTool`s, with placeholders for actual API integration logic.

**Note:** This is a conceptual demonstration focusing on ADK architecture. The tool implementations contain placeholders where real API calls would reside. To make this system fully functional, you would need to replace the placeholder logic in the tool functions (`*.py` files in the `tools/` directory) with actual API integration code for your specific external systems.

## Project Structure